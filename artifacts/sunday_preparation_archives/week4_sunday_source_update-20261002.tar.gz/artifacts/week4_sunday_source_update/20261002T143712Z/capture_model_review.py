import json
from pathlib import Path
from sqlalchemy import text
from backend.app.db import engine
from backend.app.product_services.optimizer import _json_safe
from backend.app.product_services.classic_prospective import digest_payload
p=Path(__file__).resolve().parent
new=json.loads((p/'final_refresh_lineage.json').read_text())['projection_run_id']
old='6bc7a78c-3cb7-4a6e-98db-369c5b8dd384'
with engine.connect() as c:
 models={}
 for label,pid in [('old',old),('new',new)]:
  model=dict(c.execute(text('SELECT m.* FROM target.model_run m JOIN target.projection_run p ON m.model_run_id=p.model_run_id WHERE p.projection_run_id=:pid'),{'pid':pid}).mappings().one())
  models[label]=_json_safe(model)
  features=[dict(r) for r in c.execute(text('SELECT * FROM target.feature_player_game WHERE feature_run_id=:fid ORDER BY player_id'),{'fid':model['feature_run_id']}).mappings()]
  rows=[dict(r) for r in c.execute(text('SELECT * FROM target.player_projection WHERE projection_run_id=:pid ORDER BY player_id'),{'pid':pid}).mappings()]
  if label=='new':
   (p/'model_lineage.json').write_text(json.dumps(_json_safe(model),indent=2))
   (p/'projection_features.json').write_text(json.dumps(_json_safe(features),indent=2))
   (p/'projection_records.json').write_text(json.dumps(_json_safe(rows),indent=2))
  else:
   (p/'prior_projection_readback.json').write_text(json.dumps(_json_safe(rows),indent=2))
 old_model=json.loads(Path('artifacts/week4_sunday_readiness/20261002T132342Z/model_lineage.json').read_text())
 from datetime import datetime
 for key in ('created_at','data_cutoff_at'):
  assert datetime.fromisoformat(models['old'][key])==datetime.fromisoformat(old_model[key])
 assert {k:v for k,v in models['old'].items() if k not in ('created_at','data_cutoff_at')}=={k:v for k,v in old_model.items() if k not in ('created_at','data_cutoff_at')}
before={r['player_id']:r for r in json.loads(Path('artifacts/week4_sunday_readiness/20261002T132342Z/projection_features.json').read_text())}
after={r['player_id']:r for r in _json_safe(features)}
body=dict(models=models,prior_model_readback_identical=True,prior_projection_readback_sha256=digest_payload(json.loads((p/'prior_projection_readback.json').read_text())),new_projection_sha256=digest_payload(json.loads((p/'projection_records.json').read_text())),code_hash_identical=models['old']['params_json']['code_hash']==models['new']['params_json']['code_hash'],training_dataset_identical=models['old']['params_json']['training_dataset_sha256']==models['new']['params_json']['training_dataset_sha256'],artifact_identical=models['old']['params_json']['artifact_sha256']==models['new']['params_json']['artifact_sha256'])
(p/'model_comparison.json').write_text(json.dumps(body,indent=2)); print({k:v for k,v in body.items() if k!='models'})
