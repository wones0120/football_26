"""Reviewed opt-in policy D and independent singles; no entry or default writes."""
from dataclasses import asdict, replace
from pathlib import Path
import json
import sys
from datetime import datetime, UTC
from scripts.decide_week4_sunday_portfolio import enrich, read, write, slots
from scripts.reconcile_classic_discovery_selection import Policy, solve, selected_caps, violations
from backend.app.product_services.classic_candidate_completeness import load_context, compact_candidate, capture_model, DiscoveryRequest, solve_request
from backend.app.product_services.classic_prospective import digest_payload
from backend.app.product_services.optimizer import OptimizerService

p=Path(__file__).resolve().parent
inputs=read(p/'preview_inputs.json'); bundle=read(p/'comparison.json'); ctx=load_context(inputs)
salaries={r['player_master_id']:r for r in read(p.parent/'fresh_salary_identities.json') if r['player_master_id']}
assert digest_payload({k:v for k,v in bundle.items() if k!='sha256'})==bundle['sha256']
output=p/'reviewed_recommendations.json'
if '--verify' in sys.argv:
    saved=read(output)
    assert saved['sha256']==digest_payload({k:v for k,v in saved.items() if k!='sha256'})
    assert saved['input_sha256']==digest_payload(inputs)
    results=saved['results']; policies=saved['policies']; caps=saved['caps']
else:
    base=Policy(**bundle['frozen_eligibility_policy']); selected=selected_caps(inputs)
    capped={**selected}
    for player in ctx['players']:
        if player.position in {'RB','WR','TE'}:
            capped[player.player_id]=min(capped.get(player.player_id,1),.8)
    joint=replace(base,name='reviewed_D_joint',canonical_game_cap=3)
    results={}; policies={}; caps={}
    for label,pool in [('D_full_reference',bundle['union']),('D_admitted400',bundle['targets']['400']['admitted'])]:
        value=solve(pool,joint,capped,ctx['elevated'],log_path=p/(label+'.cbc.log'))
        results[label]=enrich(value,ctx,salaries,bundle['global_known_frontier'])
        policies[label]=asdict(joint);caps[label]=capped
        print(label,results[label]['status'],results[label]['selector_sum'],flush=True)
    meyers=next(v.player_id for v in ctx['players'] if v.name=='Jakobi Meyers')
    no_meyers={**capped,meyers:0}
    value=solve(bundle['union'],joint,no_meyers,ctx['elevated'],log_path=p/'D_no_Meyers.cbc.log')
    results['D_no_Meyers']=enrich(value,ctx,salaries,bundle['global_known_frontier'])
    policies['D_no_Meyers']=asdict(joint);caps['D_no_Meyers']=no_meyers
    model=capture_model(ctx)
    single_policy=replace(base,name='existing_classic_objective_single',count=1,minimum_qbs=1,minimum_stack_types=1,canonical_game_cap=None)
    singles=solve_request(model,ctx,DiscoveryRequest('independent_single_global',maximum_groups=((tuple(sorted(ctx['elevated'] & {v.player_id for v in ctx['players']})),0),),safety_max=2),ctx['options']['solver_backend'])
    assert len(singles['rows'])==2 and all(e['status']=='optimal' for e in singles['events'])
    solver_sources={'independent_single':singles}
    for label,row in zip(('friends_small_single','friends_small_runner_up'),singles['rows']):
        results[label]=enrich(dict(status='optimal',lineups=[compact_candidate(row['player_ids'],ctx)]),ctx,salaries,bundle['global_known_frontier'])
        policies[label]=asdict(single_policy);caps[label]={v.player_id:0 if v.player_id in ctx['elevated'] else 1 for v in ctx['players']}
    preferred_qb=results['friends_small_single']['lineups'][0]['qb']['player_id']
    different=solve_request(model,ctx,DiscoveryRequest('independent_single_different_qb',maximum_groups=((tuple(sorted(ctx['elevated'] & {v.player_id for v in ctx['players']})),0),((preferred_qb,),0)),safety_max=1),ctx['options']['solver_backend'])
    assert different['events'][0]['status']=='optimal'
    results['friends_small_different_qb']=enrich(dict(status='optimal',lineups=[compact_candidate(different['rows'][0]['player_ids'],ctx)]),ctx,salaries,bundle['global_known_frontier'])
    policies['friends_small_different_qb']=asdict(single_policy);caps['friends_small_different_qb']=caps['friends_small_single']
    solver_sources['different_qb']=different
    tb=next(v.player_id for v in ctx['players'] if v.name=='Jalon Daniels')
    tb_solve=solve_request(model,ctx,DiscoveryRequest('confirmed_TB_alternative',qb_id=tb,safety_max=1),ctx['options']['solver_backend'])
    solver_sources['confirmed_TB_alternative']=tb_solve
    if tb_solve['rows']:
        results['confirmed_TB_best_legal']=enrich(dict(status=tb_solve['events'][0]['status'],lineups=[compact_candidate(tb_solve['rows'][0]['player_ids'],ctx)]),ctx,salaries,bundle['global_known_frontier'])
        policies['confirmed_TB_best_legal']=asdict(single_policy);caps['confirmed_TB_best_legal']={v.player_id:1 for v in ctx['players']}
    body=dict(contract='reviewed_sunday_D_and_independent_single_v1',created_at=datetime.now(UTC).isoformat(),mode='OPT_IN_RESEARCH_PREVIEW',entry_status='UNASSIGNED_PLANNING_ONLY',source_path=str(p.parent),comparison_sha256=bundle['sha256'],input_sha256=digest_payload(inputs),discovery_preview_run_id=bundle['preview_run_id'],projection_run_id=bundle['projection_run_id'],application_control_run_id=bundle['control_run_id'],known_reference_count=len(bundle['union']),admitted_count=len(bundle['targets']['400']['admitted']),policies=policies,caps=caps,results=results,global_solver_sources=solver_sources,production_defaults_changed=False)
    write(output,{**body,'sha256':digest_payload(body)})
count=0
for label,result in results.items():
    pol=Policy(**policies[label])
    if label!='confirmed_TB_best_legal':
        assert not violations(result['lineups'],pol,caps[label],ctx['elevated']),label
    for row in result['lineups']:
        fresh=compact_candidate(row['player_ids'],ctx)
        assert fresh['roster_sha256']==row['roster_sha256']
        assert all(abs(fresh[k]-row[k])<1e-8 for k in ('objective_score','mean','p90','salary'))
        assert slots(row,ctx,salaries)==row['slots']
        players=[OptimizerService._gpp_player_to_dict(v) for v in ctx['players'] if v.player_id in row['player_ids']]
        legal,why=OptimizerService._validate_classic_lineups([players],requested_lineups=1,max_exposure=1,enforce_single_te=True,avoid_dst_opponents=True,locked_player_ids=set(),excluded_player_ids=ctx['excluded'],excluded_opponent_teams=set())
        assert legal,(label,why)
        count+=1
print(json.dumps(dict(status='verified',checked_rosters=count,sha256=read(output)['sha256'])),flush=True)
