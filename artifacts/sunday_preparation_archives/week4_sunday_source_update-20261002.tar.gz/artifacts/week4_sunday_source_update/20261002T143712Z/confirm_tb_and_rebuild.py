from datetime import datetime, UTC
import json
from pathlib import Path
from backend.app.db import SessionLocal
from backend.app.product_services.pregame_context import PregameContextService
from backend.app.product_services.starters import StartingQBService
from backend.app.product_services.predictions import PredictionsService
from backend.app.services.lineup_learning import LineupLearningService
p=Path(__file__).resolve().parent
capture=json.loads((p/'source_issue_captures.json').read_text())['tb_start']
salaries=json.loads((p/'fresh_salary_identities.json').read_text())
daniels=next(r for r in salaries if r['team']=='TB' and r['position']=='QB' and r['source_player_key']=='44312223')
mayfield=next(r for r in salaries if r['team']=='TB' and r['position']=='QB' and r['source_player_key']=='44312214')
assert daniels['player_master_id'] and mayfield['player_master_id']
body=dict(season=2026,week=4,slate='SUNDAY_MAIN',source='official_club_start_announcement',source_uri=capture['url'],observed_at=datetime.fromisoformat(capture['retrieved_at']),notes='Club Oct 1 game preview resolves Daniels/Mayfield conflict; no expected numerical usage or final inactive list supplied.',players=[dict(player_id=daniels['player_master_id'],team='TB',position='QB',role_label='STARTER',evidence=dict(source_snapshot_id=capture['snapshot_id'],role_uncertain=False,final_game_inactives_published=False,source_publication_date='2026-10-01',reason='Official club game preview explicitly names Daniels starting against GB')),dict(player_id=mayfield['player_master_id'],team='TB',position='QB',injury_status='OUT',evidence=dict(source_snapshot_id=capture['snapshot_id'],final_game_inactives_published=False,reason='Club reports Mayfield rehab from dislocated right thumb, expected minimum three missed games'))])
(p/'tb_confirmed_context_request.json').write_text(json.dumps(body,indent=2,default=str))
context=PregameContextService().create_run(body)
selection=dict(team='TB',player_master_id=daniels['player_master_id'],source='official_club_start_announcement',source_uri=capture['url'],observed_at=capture['retrieved_at'],evidence_tier='confirmed',note='Announced starter; final game inactive clearance still pending')
starters=StartingQBService().derive_starters(2026,4,'SUNDAY_MAIN',confirmed_starters=[selection])
print('confirmed TB',context['context_run_id'],starters.message,flush=True)
with SessionLocal() as session:
    features=LineupLearningService(session).rebuild_player_game_feature_matrix(source_system='draftkings',season_start=2026,season_end=2026,slate='SUNDAY_MAIN',weeks=[4],progress_hook=lambda value:print(value,flush=True))
cutoff=datetime.now(UTC)
prediction=PredictionsService().train_and_predict(2026,4,slate='SUNDAY_MAIN',data_cutoff_at=cutoff)
result=dict(prior_new_snapshot_projection=json.loads((p/'refresh_lineage.json').read_text())['projection_run_id'],projection_run_id=str(prediction.projection_run_id),context_run_id=str(context['context_run_id']),context_request='tb_confirmed_context_request.json',starter_selection=selection,features=features,data_cutoff_at=cutoff.isoformat(),finished_at=datetime.now(UTC).isoformat(),projection_records=len(prediction.records),policy_or_model_recipe_changes=False)
(p/'final_refresh_lineage.json').write_text(json.dumps(result,indent=2,default=str));print('FINAL',result['projection_run_id'],flush=True)
