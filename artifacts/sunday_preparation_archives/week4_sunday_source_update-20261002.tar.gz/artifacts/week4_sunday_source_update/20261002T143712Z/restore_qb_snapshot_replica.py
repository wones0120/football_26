"""Relocate unreadable storage using byte-identical public data, preserving truth."""
from pathlib import Path
from datetime import datetime,UTC
import json,hashlib
import pandas as pd
from backend.app.db import SessionLocal
from backend.app.models import SourceSnapshot
from backend.app.services.source_capture import fetch_nflreadpy_dataset,verify_snapshot_artifact,SNAPSHOT_CONTRACT_ID,_stored_iso,snapshot_pre_lock
from Database.dst import normalize_team
p=Path(__file__).resolve().parent
frame,_=fetch_nflreadpy_dataset('depth_charts',season=2026,week=4)
q=frame.loc[frame['pos_abb'].fillna('').astype(str).str.upper().eq('QB')].copy()
q['observed_at']=pd.to_datetime(q['dt'],utc=True,errors='coerce');q['team_key']=q['team'].map(normalize_team);q['pos_rank']=pd.to_numeric(q['pos_rank'],errors='coerce')
q=q.loc[q.observed_at.notna() & q.observed_at.le(datetime.now(UTC)) & q.observed_at.le(datetime(2026,10,4,17,tzinfo=UTC))]
q=q.loc[q.observed_at.eq(q.groupby('team_key').observed_at.transform('max'))]
payload=q[['dt','team','gsis_id','pos_abb','pos_rank']].sort_values(['team','pos_rank','gsis_id']).to_csv(index=False,lineterminator='\n').encode()
sha=hashlib.sha256(payload).hexdigest()
with SessionLocal() as s:
 r=s.get(SourceSnapshot,'c706e1ef-34e9-5e71-b2ea-24293ab141e4');assert r.content_sha256==sha and r.byte_count==len(payload)
 before=dict(artifact_path=r.artifact_path,manifest_path=r.manifest_path)
 from backend.app.services.source_capture import SourceCaptureService
 replica=SourceCaptureService(s)._verified_local_replica(r,payload,None)
 verify_snapshot_artifact(replica)
 event=dict(snapshot_id=r.snapshot_id,content_sha256=sha,observed_at=_stored_iso(r.observed_at),before=before,after=dict(artifact_path=replica.artifact_path,manifest_path=replica.manifest_path),database_row_changed=False,raw_content_changed=False,observation_time_changed=False,reason='UI read failed with macOS EDEADLK after six retries; restored verified identical public payload to local storage',verified_at=datetime.now(UTC).isoformat())
 (p/'qb_snapshot_storage_recovery.json').write_text(json.dumps(event,indent=2));print(event)
