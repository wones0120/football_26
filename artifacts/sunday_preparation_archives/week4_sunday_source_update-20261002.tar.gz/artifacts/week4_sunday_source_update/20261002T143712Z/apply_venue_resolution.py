import json
from datetime import datetime, UTC
from pathlib import Path
from backend.app.db import SessionLocal
from backend.app.services.venue_registry import assess_venue_registry, _record_db_payload, _override_db_payload
from backend.app.models import VenueRegistryRecord, VenueGameOverride, CuratedGameVenue
p=Path(__file__).resolve().parent
seed=json.loads((p/'reviewed_venue_seed.json').read_text())
record=next(r for r in seed['venues'] if r['venue_id']=='venue-us-buf-highmark-2026')
override=next(r for r in seed['game_overrides'] if r['game_id']=='2026_04_NE_BUF')
with SessionLocal() as session:
    assessment=assess_venue_registry(session,season_start=2026,season_end=2026,seed_path=p/'reviewed_venue_seed.json')
    row=next(r for r in assessment.rows if r['game_id']=='2026_04_NE_BUF')
    assert row['mapping_status']=='resolved'
    for cls,values,idkey in [(VenueRegistryRecord,_record_db_payload(record),'registry_record_id'),(VenueGameOverride,_override_db_payload(override),'override_id')]:
        existing=session.get(cls,values[idkey])
        if existing: assert existing.definition_sha256==values['definition_sha256']
        else: session.add(cls(**values))
        session.flush()
    mapping=session.get(CuratedGameVenue,row['game_id'])
    before={k:getattr(mapping,k) for k in row}
    for k,v in row.items():setattr(mapping,k,v)
    session.commit()
    report=dict(status='resolved',scope='one canonical game only; no other mappings replaced',before=before,after=row,new_registry_record=record,game_override=override,applied_at=datetime.now(UTC).isoformat())
    with (p/'venue_resolution.json').open('x') as f:json.dump(report,f,indent=2,default=str)
    print(row['game_id'],row['mapping_status'],row['mapping_method'])
