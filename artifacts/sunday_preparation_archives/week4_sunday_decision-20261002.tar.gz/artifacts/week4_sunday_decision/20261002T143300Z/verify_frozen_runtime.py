"""Replay the immutable comparison with its archived, hash-verified runtime."""
from pathlib import Path
import runpy,sys
import backend.app.product_services as package
root=Path(__file__).resolve().parents[3]
package.__path__.insert(0,str(Path(__file__).resolve().parent/'runtime_before_ui_integration'))
sys.argv=['decide_week4_sunday_portfolio','--frozen',str(root/'artifacts/week4_sunday_readiness/20261002T132342Z'),'--output',str(Path(__file__).resolve().parent),'--verify']
runpy.run_module('scripts.decide_week4_sunday_portfolio',run_name='__main__')
