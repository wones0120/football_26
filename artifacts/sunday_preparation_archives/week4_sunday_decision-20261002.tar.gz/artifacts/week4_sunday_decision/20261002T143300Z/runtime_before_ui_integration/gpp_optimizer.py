"""GPP-focused lineup optimizer with slate-aware config and feedback loop."""

from __future__ import annotations

import math
import uuid
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, datetime
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import pandas as pd
import pulp
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from Database.config import get_connection_string

from .cbc_solver import make_cbc_solver
from .optimizer_control import solve_control, build_comparison
from .lineup_correlation_scoring import (
    add_format_specific_objective,
    add_lineup_correlation_objective,
    build_format_specific_terms,
    build_lineup_correlation_terms,
    _threshold_flag,
)
from .rule_library import resolve_strategy_profile


Position = str


@dataclass
class Player:
    player_id: str
    name: str
    team: str
    opponent: str
    position: Position
    salary: int
    projection: float
    ceiling: float
    ownership: float | None
    optimal_lineup_probability: float | None = None
    game_id: str | None = None
    spread: float | None = None
    game_total: float | None = None
    team_total: float | None = None
    market_context_point_in_time_safe: bool | None = None
    optimizer_context_adjustment: float = 0.0
    optimizer_context_rule_evaluation: dict | None = None
    optimizer_receiving_role_strength: float = 0.0
    optimizer_rushing_role_strength: float = 0.0
    tags: set[str] = field(default_factory=set)
    value_per_k: float = 0.0
    ceiling_per_k: float = 0.0
    leverage: float = 0.0


OWNERSHIP_BUCKET_ORDER = ["mega_chalk", "chalk", "popular", "mid", "low", "dart", "unknown"]


def ownership_bucket(ownership: float | None) -> str:
    if ownership is None or not math.isfinite(float(ownership)):
        return "unknown"
    pct = float(ownership)
    if pct >= 30:
        return "mega_chalk"
    if pct >= 20:
        return "chalk"
    if pct >= 15:
        return "popular"
    if pct >= 10:
        return "mid"
    if pct >= 5:
        return "low"
    if pct >= 0:
        return "dart"
    return "unknown"


@dataclass
class SlateAnalysis:
    game_count: int
    chalk_concentration: float
    feature_games: List[Tuple[str, float]]


@dataclass
class StackRules:
    min_pass_catchers: int = 1
    min_bring_backs: int = 1
    max_from_team: int = 4
    max_from_game: int | None = None
    pass_catcher_positions: Sequence[Position] = field(default_factory=lambda: ["WR", "TE", "RB"])
    bring_back_positions: Sequence[Position] = field(default_factory=lambda: ["RB", "WR", "TE"])


@dataclass
class TagThresholds:
    chalk_proj: float = 15.0
    chalk_own: float = 15.0
    leverage_proj: float = 10.0
    leverage_own: float = 12.0
    leverage_min: float = 0.0
    punt_salary: int = 3500


@dataclass
class ObjectiveWeights:
    projection: float = 1.0
    ceiling: float = 0.0
    leverage: float = 0.25
    correlation: float = 0.2


@dataclass
class LineupTagCaps:
    max_chalk: int = 4
    min_leverage: int = 2
    max_punts: int = 2
    max_total_ownership: float | None = None


@dataclass
class PortfolioTargets:
    max_avg_ownership: float | None = 140.0
    min_leverage_count: int = 2
    max_chalk_count: int = 4
    player_exposure_caps: Dict[str, float] = field(default_factory=dict)  # player_id -> max exposure (0-1)
    player_exposure_mins: Dict[str, float] = field(default_factory=dict)  # player_id -> min exposure (0-1)


@dataclass
class SlateConfig:
    stack_rules: StackRules
    tag_thresholds: TagThresholds
    objective_weights: ObjectiveWeights
    tag_caps: LineupTagCaps
    salary_cap: int = 50000
    roster_size: int = 9
    portfolio_targets: PortfolioTargets = field(default_factory=PortfolioTargets)
    correlation_bonus: float = 0.5
    uniqueness_overlap: int = 7  # max shared players between lineups
    normalize_objective: bool = False
    stack_templates: Sequence[Tuple[int, int]] = field(default_factory=tuple)


@dataclass
class PortfolioStats:
    exposures: Dict[str, float]
    tag_counts: Dict[str, int]
    avg_total_ownership: float | None
    stack_summary: Dict[str, int]
    avg_template_score: float | None = None
    template_score_counts: Dict[str, int] = field(default_factory=dict)


@dataclass
class GPPOptimizerResult:
    job_id: str
    status: str
    message: str
    created_at: datetime
    updated_at: datetime
    lineups: List[List[Player]]
    config: SlateConfig
    analysis: SlateAnalysis
    portfolio: PortfolioStats
    iterations: int
    control_comparisons: List[dict] = field(default_factory=list)
    generation_funnel: dict = field(default_factory=dict)


VALID_POSITIONS = {"QB", "RB", "WR", "TE", "DST", "D", "DEF"}


def _normalize_position(pos: str | None) -> str:
    return (pos or "").upper().split("/")[0].strip()


def _normalize_alias(name: str) -> str:
    """Map common aliases to canonical forms (e.g., Hollywood Brown -> Marquise Brown)."""
    key = " ".join(name.lower().replace("'", " ").split())
    if "hollywood brown" in key or ("hollywood" in key and "brown" in key):
        return "marquise brown"
    if key == "marquise brown":
        return "marquise brown"
    return key


def _coalesce_projection(df: pd.DataFrame) -> pd.Series:
    """
    Build a numeric projection column using priority:
    1) projection (post-merge / name-team match)
    2) predicted_mean
    3) adj_mean_final
    4) average_points_per_game / AvgPointsPerGame (from salaries)
    """
    def _col(name: str) -> pd.Series:
        if name in df.columns:
            return pd.to_numeric(df[name], errors="coerce")
        return pd.Series([pd.NA] * len(df), index=df.index)

    proj = _col("projection")
    pred_mean = _col("predicted_mean")
    adj_mean = _col("adj_mean_final")
    avg_pts = _col("average_points_per_game")
    if avg_pts.isna().all() and "AvgPointsPerGame" in df.columns:
        avg_pts = _col("AvgPointsPerGame")

    filled = proj.copy()
    filled = filled.fillna(pred_mean)
    filled = filled.fillna(adj_mean)
    filled = filled.fillna(avg_pts)
    return filled.fillna(0)


def load_player_pool(engine: Engine, season: int, week: int, slate: str) -> tuple[List[Player], dict]:
    """Load salaries + projections + ownership for a slate, with diagnostic counts."""
    with engine.begin() as connection:
        salaries = pd.read_sql(
            text(
                "SELECT * FROM curated_salaries WHERE season = :season AND week = :week AND slate = :slate"
            ),
            connection,
            params={"season": season, "week": week, "slate": slate},
        )
        if "player_id" not in salaries.columns and "ID" in salaries.columns:
            salaries["player_id"] = salaries["ID"]
        projections = pd.read_sql(
            text(
                "SELECT player_id, player_master_id, player_display_name, recent_team, "
                "predicted_mean, predicted_p90, predicted_p50, adj_mean_final "
                "FROM player_expected_points "
                "WHERE season = :season AND week = :week AND (slate = :slate OR slate IS NULL)"
            ),
            connection,
            params={"season": season, "week": week, "slate": slate},
        )
        try:
            adjusted = pd.read_sql(
                text(
                    "SELECT DISTINCT ON (player_id) player_id, rule_run_id, adjusted_mean, adjusted_p90, reason "
                    "FROM player_expected_points_adjusted "
                    "WHERE season = :season AND week = :week AND (slate = :slate OR slate IS NULL) "
                    "ORDER BY player_id, created_at DESC"
                ),
                connection,
                params={"season": season, "week": week, "slate": slate},
            )
        except Exception:
            adjusted = pd.DataFrame()
        if not projections.empty and not adjusted.empty:
            projections = projections.merge(adjusted, on="player_id", how="left")
            projections["adj_mean_final"] = projections["adjusted_mean"].fillna(
                projections.get("adj_mean_final", projections.get("predicted_mean"))
            )
            projections["predicted_p90"] = projections["adjusted_p90"].fillna(
                projections.get("predicted_p90")
            )
        injuries = pd.read_sql(
            text(
                "SELECT player_id, player_master_id, nickname, first_name, last_name, team, injury_indicator "
                "FROM weekly_injuries "
                "WHERE season = :season AND week = :week AND (slate = :slate OR slate IS NULL)"
            ),
            connection,
            params={"season": season, "week": week, "slate": slate},
        )
        try:
            ownership = pd.read_sql(
                text(
                    "SELECT player_id, projected_ownership FROM dk_ownership "
                    "WHERE season = :season AND week = :week AND (slate = :slate OR slate IS NULL)"
                ),
                connection,
                params={"season": season, "week": week, "slate": slate},
            )
        except Exception:
            ownership = pd.DataFrame(columns=["player_id", "projected_ownership"])

    counts = {
        "salaries": len(salaries),
        "projections": len(projections),
        "ownership": len(ownership),
    }

    if salaries.empty:
        return [], counts

    # Normalize ids/types
    salaries["player_id"] = salaries["player_id"].astype(str)
    if "player_master_id" in salaries.columns:
        salaries["player_id"] = salaries["player_master_id"].fillna(salaries["player_id"])
    if "dk_player_id" not in salaries.columns:
        if "ID" in salaries.columns:
            salaries["dk_player_id"] = salaries["ID"]
        else:
            salaries["dk_player_id"] = salaries["player_id"]
    # Normalize salary numeric column
    if "salary" not in salaries.columns:
        if "Salary" in salaries.columns:
            salaries["salary"] = pd.to_numeric(salaries["Salary"], errors="coerce")
        else:
            salaries["salary"] = 0
    else:
        salaries["salary"] = pd.to_numeric(salaries["salary"], errors="coerce")
    projections["player_id"] = projections["player_id"].astype(str) if not projections.empty else pd.Series([], dtype=str)
    ownership["player_id"] = ownership["player_id"].astype(str) if not ownership.empty else pd.Series([], dtype=str)
    injuries["player_id"] = injuries["player_id"].astype(str) if not injuries.empty else pd.Series([], dtype=str)

    def _norm_name(series: pd.Series) -> pd.Series:
        return series.astype(str).str.lower().str.replace(r"\\s+", " ", regex=True).str.strip().map(_normalize_alias)

    salaries["name_norm"] = _norm_name(
        salaries.get("name", salaries.get("player_name", pd.Series("", index=salaries.index)))
    )
    salaries["team_norm"] = salaries.get("player_team", salaries.get("team", pd.Series("", index=salaries.index))).astype(str).str.upper()

    projections["name_norm"] = _norm_name(
        projections.get(
            "player_display_name",
            projections.get("player_name", pd.Series("", index=projections.index)),
        )
    )
    projections["team_norm"] = projections.get("recent_team", pd.Series("", index=projections.index)).astype(str).str.upper()

    if not projections.empty:
        projections = projections.sort_values(by=["adj_mean_final", "predicted_mean"], ascending=False)
        projections = projections.drop_duplicates(subset=["player_id"], keep="first")

    merged = salaries.merge(projections, on="player_id", how="left", suffixes=("", "_proj"))
    merged = merged.merge(ownership, on="player_id", how="left")

    # Secondary match on normalized name + team if projection missing
    if "projection" not in merged.columns:
        merged["projection"] = merged.get("predicted_mean")
    missing_proj_mask = merged["projection"].isna()
    if missing_proj_mask.any():
        proj_lookup = projections.set_index(["name_norm", "team_norm"])
        for idx in merged[missing_proj_mask].index:
            key = (merged.at[idx, "name_norm"], str(merged.at[idx, "team_norm"]).upper())
            if key in proj_lookup.index:
                matched = proj_lookup.loc[key]
                merged.at[idx, "projection"] = matched.get("adj_mean_final") or matched.get("predicted_mean")
                merged.at[idx, "predicted_p90"] = matched.get("predicted_p90")
                merged.at[idx, "predicted_p50"] = matched.get("predicted_p50")

    merged["projection"] = _coalesce_projection(merged)
    # Prefer readable names for downstream display
    if "player_display_name" in merged.columns:
        merged["name"] = merged["player_display_name"]
        merged["player_name"] = merged["player_display_name"]
    elif "name" not in merged.columns and "player_name" in merged.columns:
        merged["name"] = merged["player_name"]

    # Build injury filters (block IR/OUT)
    block_tokens = ("OUT", "IR", "PUP", "NFI", "RESERVE")
    injured = injuries.copy()
    if not injured.empty:
        injured["injury_indicator"] = injured["injury_indicator"].astype(str).str.upper().fillna("")
        injured = injured[injured["injury_indicator"].str.contains("|".join(block_tokens))]
        injured["name_norm"] = _norm_name(
            injured.get(
                "nickname",
                injured.get("first_name", pd.Series("", index=injured.index))
                + " "
                + injured.get("last_name", pd.Series("", index=injured.index)),
            )
        )
        injured["team_norm"] = injured.get("team", pd.Series("", index=injured.index)).astype(str).str.upper()
        blocked_ids = set(injured["player_id"].dropna().astype(str))
        if "player_master_id" in injured.columns:
            blocked_ids |= set(injured["player_master_id"].dropna().astype(str))
        blocked_name_team = {(r.name_norm, r.team_norm) for r in injured.itertuples() if r.name_norm}
    else:
        blocked_ids = set()
        blocked_name_team = set()

    def _proj(row: pd.Series) -> float:
        for key in ("adj_mean_final", "predicted_mean", "average_points_per_game"):
            if key in row and pd.notna(row[key]):
                try:
                    val = float(row[key])
                    if val > 0:
                        return val
                except Exception:
                    continue
        return 0.0

    def _ceiling(row: pd.Series) -> float:
        if "predicted_p90" in row and pd.notna(row["predicted_p90"]):
            try:
                val = float(row["predicted_p90"])
                return val if math.isfinite(val) else 0.0
            except Exception:
                return 0.0
        if "predicted_p50" in row and pd.notna(row["predicted_p50"]):
            try:
                val = float(row["predicted_p50"]) * 1.15
                return val if math.isfinite(val) else 0.0
            except Exception:
                return 0.0
        try:
            val = float(getattr(row, "projection", 0.0) or 0.0)
            return val if math.isfinite(val) else 0.0
        except Exception:
            return 0.0

    players: List[Player] = []
    dropped_salary = 0
    dropped_pos = 0
    dropped_proj = 0
    no_proj_match = 0
    if "projection" in merged.columns:
        predicted_missing = merged.get("predicted_mean").isna() if "predicted_mean" in merged else pd.Series(True, index=merged.index)
        projection_missing = merged["projection"].isna()
        no_proj_match = int(merged[predicted_missing & projection_missing].shape[0])
    for row in merged.itertuples():
        pos = _normalize_position(getattr(row, "position", "") or getattr(row, "roster_position", ""))
        if pos not in VALID_POSITIONS:
            dropped_pos += 1
            continue
        salary = int(getattr(row, "salary", 0) or 0)
        if salary <= 0:
            dropped_salary += 1
            continue
        # Skip blocked injuries
        name_team_key = (
            getattr(row, "name_norm", None),
            getattr(row, "team_norm", None),
        )
        if str(row.player_id) in blocked_ids or name_team_key in blocked_name_team:
            dropped_proj += 1
            continue
        try:
            projection = float(getattr(row, "projection", 0) or 0)
        except Exception:
            projection = 0.0
        if not math.isfinite(projection) or projection <= 0:
            dropped_proj += 1
            continue
        ceiling = _ceiling(row)
        try:
            ownership_val = float(getattr(row, "projected_ownership", None))
            if not math.isfinite(ownership_val):
                ownership_val = None
        except Exception:
            ownership_val = None
        player = Player(
            player_id=str(row.player_id),
            name=str(getattr(row, "name", getattr(row, "player_name", row.player_id))),
            team=str(getattr(row, "player_team", getattr(row, "team", ""))).upper(),
            opponent=str(getattr(row, "opponent_team", getattr(row, "opponent", ""))).upper(),
            position=pos,
            salary=salary,
            projection=projection,
            ceiling=ceiling,
            ownership=ownership_val,
            game_id=str(getattr(row, "game_info", getattr(row, "game_id", ""))),
            spread=(float(row.spread) if hasattr(row, "spread") and pd.notna(row.spread) else None),
            game_total=(float(row.game_total) if hasattr(row, "game_total") and pd.notna(row.game_total) else None),
            team_total=(float(row.team_total) if hasattr(row, "team_total") and pd.notna(row.team_total) else None),
        )
        players.append(player)
    counts.update(
        {
            "kept": len(players),
            "dropped_salary": dropped_salary,
            "dropped_pos": dropped_pos,
            "dropped_proj": dropped_proj,
            "missing_projection_match": no_proj_match,
        }
    )
    return players, counts


def tag_players(players: List[Player], thresholds: TagThresholds) -> None:
    for p in players:
        p.value_per_k = p.projection / max(1, p.salary / 1000)
        p.ceiling_per_k = p.ceiling / max(1, p.salary / 1000)
        p.leverage = (
            p.optimal_lineup_probability - p.ownership
            if p.optimal_lineup_probability is not None and p.ownership is not None
            else 0.0
        )
        p.tags = set()
        if p.ownership is not None and p.projection >= thresholds.chalk_proj and p.ownership >= thresholds.chalk_own:
            p.tags.add("chalk")
        if (
            p.optimal_lineup_probability is not None
            and p.leverage > thresholds.leverage_min
        ):
            p.tags.add("leverage")
        if p.salary <= thresholds.punt_salary:
            p.tags.add("punt")
        p.tags.add(f"own_{ownership_bucket(p.ownership)}")


def classic_template_score(lineup: List[Player]) -> int | None:
    if any(player.ownership is None for player in lineup):
        return None
    buckets: Dict[str, int] = {bucket: 0 for bucket in OWNERSHIP_BUCKET_ORDER}
    for player in lineup:
        buckets[ownership_bucket(player.ownership)] += 1
    total_ownership = sum(player.ownership for player in lineup)
    score = 0
    if len(lineup) == 9:
        score += 1
    if 120 <= total_ownership <= 180:
        score += 2
    elif 100 <= total_ownership <= 200:
        score += 1
    if 1 <= buckets["mega_chalk"] <= 3:
        score += 2
    if 2 <= buckets["mega_chalk"] + buckets["chalk"] <= 4:
        score += 1
    if 2 <= buckets["low"] + buckets["dart"] <= 4:
        score += 2
    if 1 <= buckets["dart"] <= 3:
        score += 1
    if any(player.position == "RB" and ownership_bucket(player.ownership) in {"chalk", "mega_chalk"} for player in lineup):
        score += 1
    if any(player.position in {"DST", "D", "DEF"} and player.ownership < 20 for player in lineup):
        score += 1
    if any(player.position == "WR" and ownership_bucket(player.ownership) in {"low", "dart"} for player in lineup):
        score += 1
    return score


def template_score_bucket(score: int) -> str:
    if score >= 8:
        return "strong"
    if score <= 4:
        return "weak"
    return "neutral"


def analyze_slate(players: List[Player], chalk_threshold: float = 20.0) -> SlateAnalysis:
    game_ids = {p.game_id for p in players if p.game_id}
    totals = {}
    for p in players:
        if p.game_id and p.game_total:
            totals[p.game_id] = max(totals.get(p.game_id, 0.0), p.game_total)
    feature_games = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)[:3]
    chalky = [p for p in players if p.ownership is not None and p.ownership >= chalk_threshold]
    chalk_concentration = len(chalky) / max(1, len(players))
    return SlateAnalysis(
        game_count=len(game_ids) if game_ids else math.ceil(len(players) / 18),  # rough estimate
        chalk_concentration=chalk_concentration,
        feature_games=feature_games,
    )


def build_slate_config(analysis: SlateAnalysis) -> SlateConfig:
    # Stack defaults adjust with slate size: shorter slates -> more stacking
    if analysis.game_count <= 3:
        stacks = StackRules(min_pass_catchers=2, min_bring_backs=1, max_from_team=4)
        tag_caps = LineupTagCaps(max_chalk=3, min_leverage=3, max_punts=1, max_total_ownership=140.0)
        weights = ObjectiveWeights(projection=1.0, leverage=0.35, correlation=0.25)
    elif analysis.game_count <= 6:
        stacks = StackRules(min_pass_catchers=2, min_bring_backs=1, max_from_team=4)
        tag_caps = LineupTagCaps(max_chalk=4, min_leverage=2, max_punts=2, max_total_ownership=150.0)
        weights = ObjectiveWeights(projection=1.0, leverage=0.3, correlation=0.2)
    else:
        stacks = StackRules(min_pass_catchers=1, min_bring_backs=1, max_from_team=4)
        tag_caps = LineupTagCaps(max_chalk=5, min_leverage=1, max_punts=2, max_total_ownership=160.0)
        weights = ObjectiveWeights(projection=1.0, leverage=0.25, correlation=0.15)

    tag_thresholds = TagThresholds()
    targets = PortfolioTargets(
        max_avg_ownership=tag_caps.max_total_ownership or 150.0,
        min_leverage_count=tag_caps.min_leverage,
        max_chalk_count=tag_caps.max_chalk,
    )
    return SlateConfig(
        stack_rules=stacks,
        tag_thresholds=tag_thresholds,
        objective_weights=weights,
        tag_caps=tag_caps,
        portfolio_targets=targets,
    )


def build_large_gpp_config(
    analysis: SlateAnalysis,
    *,
    ownership_available: bool,
    minimum_uniqueness: int = 2,
    max_from_team: int | None = None,
    max_from_game: int | None = None,
    stack_templates: Sequence[Tuple[int, int]] | None = None,
    maximum_exposure_by_player: Dict[str, float] | None = None,
    minimum_exposure_by_player: Dict[str, float] | None = None,
    candidate_aware_ownership: bool = False,
) -> SlateConfig:
    """Build the explicit large-field tournament contract.

    The common validation floor is QB + one eligible teammate. Individual
    lineups cycle through several stronger templates so the portfolio is not
    forced into one identical construction.
    """
    templates = tuple(stack_templates or ((1, 0), (1, 1), (2, 0), (2, 1)))
    if not templates:
        templates = ((1, 0),)
    mean_weight = 0.35
    ceiling_weight = 0.48 if candidate_aware_ownership else (0.45 if ownership_available else 0.48)
    correlation_weight = 0.17 if candidate_aware_ownership else (0.15 if ownership_available else 0.17)
    leverage_weight = 0.0 if candidate_aware_ownership else (0.05 if ownership_available else 0.0)
    team_cap = int(max_from_team) if max_from_team is not None else 4
    team_cap = max(1, min(4, team_cap))
    uniqueness = max(1, min(9, int(minimum_uniqueness)))
    ownership_cap = 160.0 if ownership_available and not candidate_aware_ownership else None
    return SlateConfig(
        stack_rules=StackRules(
            min_pass_catchers=min(template[0] for template in templates),
            min_bring_backs=min(template[1] for template in templates),
            max_from_team=team_cap,
            max_from_game=(
                max(1, min(9, int(max_from_game)))
                if max_from_game is not None
                else None
            ),
            pass_catcher_positions=("WR", "TE"),
            bring_back_positions=("RB", "WR", "TE"),
        ),
        tag_thresholds=TagThresholds(),
        objective_weights=ObjectiveWeights(
            projection=mean_weight,
            ceiling=ceiling_weight,
            leverage=leverage_weight,
            correlation=correlation_weight,
        ),
        tag_caps=LineupTagCaps(
            max_chalk=5 if ownership_available and not candidate_aware_ownership else 9,
            min_leverage=0,
            max_punts=2,
            max_total_ownership=ownership_cap,
        ),
        portfolio_targets=PortfolioTargets(
            max_avg_ownership=ownership_cap,
            min_leverage_count=0,
            max_chalk_count=5 if ownership_available and not candidate_aware_ownership else 9,
            player_exposure_caps=dict(maximum_exposure_by_player or {}),
            player_exposure_mins=dict(minimum_exposure_by_player or {}),
        ),
        correlation_bonus=1.0,
        uniqueness_overlap=9 - uniqueness,
        normalize_objective=True,
        stack_templates=templates,
    )


def build_long_shot_config(
    config: SlateConfig,
    *,
    ownership_available: bool,
) -> SlateConfig:
    """Return a one-lineup contrarian objective without changing projections.

    Ownership is the only direct evidence that a lineup is contrarian.  When it
    is unavailable, keep the ordinary football objective and let the caller
    report that long-shot confidence is unavailable instead of treating missing
    ownership as zero.
    """
    if not ownership_available:
        return config
    return replace(
        config,
        objective_weights=ObjectiveWeights(
            projection=0.15,
            ceiling=0.30,
            leverage=0.40,
            correlation=0.15,
        ),
        tag_caps=replace(
            config.tag_caps,
            max_chalk=config.roster_size,
            min_leverage=0,
            max_total_ownership=None,
        ),
        portfolio_targets=replace(
            config.portfolio_targets,
            max_avg_ownership=None,
            min_leverage_count=0,
            max_chalk_count=config.roster_size,
        ),
    )


def _position_indices(players: List[Player], positions: Iterable[Position]) -> List[int]:
    allowed = {p.upper() for p in positions}
    return [i for i, p in enumerate(players) if p.position in allowed]


def _build_lineup(
    players: List[Player],
    config: SlateConfig,
    exposure_remaining: Dict[str, int] | None,
    exclude_lineups: List[set],
    *,
    enforce_single_te: bool = False,
    avoid_dst_opponents: bool = False,
    stack_rules: StackRules | None = None,
    required_player_ids: set[str] | None = None,
    control_comparisons: List[dict] | None = None,
    exact_pass_catchers: int | None = None,
    exact_bring_backs: int | None = None,
    correlation_rule_multipliers: Mapping[str, float] | None = None,
    extra_qb_pass_catcher_multiplier: float = 1.0,
    precomputed_correlation_terms: Sequence[Any] | None = None,
    precomputed_format_terms: Sequence[Any] | None = None,
    minimum_mean: float | None = None,
    minimum_p90: float | None = None,
    minimum_player_groups: Sequence[tuple[set[str], int]] | None = None,
    maximum_player_groups: Sequence[tuple[set[str], int]] | None = None,
    solver_backend: str = "bundled",
) -> Optional[List[int]]:
    if not players:
        return None

    idx_range = range(len(players))
    x = pulp.LpVariable.dicts("p", idx_range, lowBound=0, upBound=1, cat="Binary")
    model = pulp.LpProblem("GPP", pulp.LpMaximize)

    # Objective
    weights = config.objective_weights
    adjusted_projections = [
        player.projection + player.optimizer_context_adjustment
        for player in players
    ]
    adjusted_ceilings = [
        player.ceiling + player.optimizer_context_adjustment
        for player in players
    ]
    if config.normalize_objective:
        max_projection = max(1.0, max(adjusted_projections))
        max_ceiling = max(1.0, max(adjusted_ceilings))
        max_abs_leverage = max(
            1.0, max(abs(player.leverage) for player in players)
        )
        proj_term = pulp.lpSum(
            (adjusted_projections[i] / max_projection) * x[i] for i in idx_range
        )
        ceiling_term = pulp.lpSum(
            (adjusted_ceilings[i] / max_ceiling) * x[i] for i in idx_range
        )
        lev_term = pulp.lpSum(
            (players[i].leverage / max_abs_leverage) * x[i] for i in idx_range
        )
    else:
        proj_term = pulp.lpSum(adjusted_projections[i] * x[i] for i in idx_range)
        ceiling_term = pulp.lpSum(adjusted_ceilings[i] * x[i] for i in idx_range)
        lev_term = pulp.lpSum(players[i].leverage * x[i] for i in idx_range)
    # Keep normalization denominators fixed to isolate only soft-rule scoring.
    context_multiplier = weights.projection / (max_projection if config.normalize_objective else 1.0) + weights.ceiling / (max_ceiling if config.normalize_objective else 1.0)
    control_objective = weights.projection * proj_term + weights.ceiling * ceiling_term + weights.leverage * lev_term - pulp.lpSum(
        players[i].optimizer_context_adjustment * context_multiplier * x[i] for i in idx_range
    )
    correlation_profile = resolve_strategy_profile(
        contest_format="classic", objective="gpp"
    )
    correlation_terms = list(precomputed_correlation_terms) if precomputed_correlation_terms is not None else build_lineup_correlation_terms(
        players, profile=correlation_profile
    )
    format_terms = list(precomputed_format_terms) if precomputed_format_terms is not None else build_format_specific_terms(
        players, profile=correlation_profile
    )
    rule_multipliers = dict(correlation_rule_multipliers or {})

    def adjusted_rule_score(evaluation: Any) -> float:
        return sum(
            trigger.score_contribution * rule_multipliers.get(trigger.rule_id, 1.0)
            for trigger in evaluation.triggered_rules
        )

    if rule_multipliers:
        correlation_terms = [
            replace(term, adjustment=adjusted_rule_score(term.evaluation))
            for term in correlation_terms
        ]
        format_terms = [
            replace(term, adjustment=adjusted_rule_score(term.evaluation))
            for term in format_terms
        ]
    correlation_score = add_lineup_correlation_objective(
        model,
        correlation_terms,
        selected_vars=x,
        prefix="gpp_rule_correlation",
    )
    format_score = add_format_specific_objective(
        model,
        format_terms,
        selected_vars=x,
        prefix="gpp_format_rule",
    )
    resolved_extra_multiplier = float(extra_qb_pass_catcher_multiplier)
    if not 0.0 <= resolved_extra_multiplier <= 1.0:
        raise ValueError("extra_qb_pass_catcher_multiplier must be between 0 and 1")
    extra_stack_adjustments: list[Any] = []
    if resolved_extra_multiplier < 1.0:
        qb_pass_catcher_rule = "correlation.qb_pass_catcher_v2"
        by_qb: dict[int, list[tuple[int, float]]] = {}
        for term in correlation_terms:
            trigger = next(
                (
                    item
                    for item in term.evaluation.triggered_rules
                    if item.rule_id == qb_pass_catcher_rule
                ),
                None,
            )
            if trigger is None:
                continue
            if players[term.left_index].position == "QB":
                qb_index, catcher_index = term.left_index, term.right_index
            elif players[term.right_index].position == "QB":
                qb_index, catcher_index = term.right_index, term.left_index
            else:
                continue
            by_qb.setdefault(qb_index, []).append(
                (catcher_index, float(trigger.score_contribution))
            )
        for qb_index, catcher_rows in by_qb.items():
            catcher_indexes = tuple(dict.fromkeys(index for index, _score in catcher_rows))
            if len(catcher_indexes) < 2:
                continue
            scores = [score for _index, score in catcher_rows]
            per_extra_score = sum(scores) / len(scores)
            catcher_count = pulp.lpSum(x[index] for index in catcher_indexes)
            for threshold in range(2, len(catcher_indexes) + 1):
                threshold_flags = _threshold_flag(
                    model,
                    catcher_count,
                    item_count=len(catcher_indexes),
                    minimum=threshold,
                    maximum=None,
                    prefix=f"gpp_extra_qb_pass_catcher_{qb_index}_{threshold}",
                )
                if not threshold_flags:
                    continue
                active = pulp.LpVariable(
                    f"gpp_extra_qb_pass_catcher_{qb_index}_{threshold}_active",
                    lowBound=0,
                    upBound=1,
                    cat="Binary",
                )
                conditions = [x[qb_index], *threshold_flags]
                for condition in conditions:
                    model += active <= condition
                model += active >= pulp.lpSum(conditions) - (len(conditions) - 1)
                extra_stack_adjustments.append(
                    -(1.0 - resolved_extra_multiplier) * per_extra_score * active
                )
    extra_stack_score = pulp.lpSum(extra_stack_adjustments)
    model += (
        weights.projection * proj_term
        + weights.ceiling * ceiling_term
        + weights.leverage * lev_term
        + weights.correlation
        * config.correlation_bonus
        * (correlation_score + format_score + extra_stack_score)
    )

    # Salary + roster
    model += pulp.lpSum(players[i].salary * x[i] for i in idx_range) <= config.salary_cap
    model += pulp.lpSum(x[i] for i in idx_range) == config.roster_size
    if minimum_mean is not None:
        model += pulp.lpSum(players[i].projection * x[i] for i in idx_range) >= minimum_mean
    if minimum_p90 is not None:
        model += pulp.lpSum(players[i].ceiling * x[i] for i in idx_range) >= minimum_p90

    qb_idx = _position_indices(players, ["QB"])
    rb_idx = _position_indices(players, ["RB"])
    wr_idx = _position_indices(players, ["WR"])
    te_idx = _position_indices(players, ["TE"])
    dst_idx = _position_indices(players, ["DST", "D", "DEF"])
    model += pulp.lpSum(x[i] for i in qb_idx) == 1
    model += pulp.lpSum(x[i] for i in dst_idx) == 1
    model += pulp.lpSum(x[i] for i in rb_idx) >= 2
    model += pulp.lpSum(x[i] for i in wr_idx) >= 3
    model += pulp.lpSum(x[i] for i in te_idx) >= 1
    if enforce_single_te:
        model += pulp.lpSum(x[i] for i in te_idx) <= 1

    # Team limits
    active_stack_rules = stack_rules or config.stack_rules
    for team in sorted({p.team for p in players}):
        team_idx = [i for i, p in enumerate(players) if p.team == team]
        model += pulp.lpSum(x[i] for i in team_idx) <= active_stack_rules.max_from_team
    if active_stack_rules.max_from_game is not None:
        for game_id in sorted({p.game_id for p in players if p.game_id}):
            game_idx = [i for i, p in enumerate(players) if p.game_id == game_id]
            model += (
                pulp.lpSum(x[i] for i in game_idx)
                <= active_stack_rules.max_from_game
            )

    if avoid_dst_opponents:
        for dst_index in dst_idx:
            dst_opponent = players[dst_index].opponent
            if not dst_opponent:
                continue
            for player_index, player in enumerate(players):
                if player.position in {"DST", "D", "DEF"}:
                    continue
                if player.team == dst_opponent:
                    model += x[player_index] + x[dst_index] <= 1

    # Stacking: pass catchers and bring-backs
    for i in qb_idx:
        qb = players[i]
        same_team = [j for j, p in enumerate(players) if p.team == qb.team and p.position in active_stack_rules.pass_catcher_positions and j != i]
        opp_team = [
            j
            for j, p in enumerate(players)
            if p.team == qb.opponent
            and p.position in active_stack_rules.bring_back_positions
        ]
        if same_team:
            model += pulp.lpSum(x[j] for j in same_team) >= active_stack_rules.min_pass_catchers * x[i]
        if opp_team:
            model += pulp.lpSum(x[j] for j in opp_team) >= active_stack_rules.min_bring_backs * x[i]
        if exact_pass_catchers is not None:
            model += pulp.lpSum(x[j] for j in same_team) >= exact_pass_catchers * x[i]
            model += pulp.lpSum(x[j] for j in same_team) <= exact_pass_catchers + len(same_team) * (1 - x[i])
        if exact_bring_backs is not None:
            model += pulp.lpSum(x[j] for j in opp_team) >= exact_bring_backs * x[i]
            model += pulp.lpSum(x[j] for j in opp_team) <= exact_bring_backs + len(opp_team) * (1 - x[i])

    # Tag constraints
    tag_caps = config.tag_caps
    chalk_idx = [i for i, p in enumerate(players) if "chalk" in p.tags]
    lev_idx = [i for i, p in enumerate(players) if "leverage" in p.tags]
    punt_idx = [i for i, p in enumerate(players) if "punt" in p.tags]
    if chalk_idx:
        model += pulp.lpSum(x[i] for i in chalk_idx) <= tag_caps.max_chalk
    if lev_idx:
        model += pulp.lpSum(x[i] for i in lev_idx) >= tag_caps.min_leverage
    if punt_idx:
        model += pulp.lpSum(x[i] for i in punt_idx) <= tag_caps.max_punts
    if tag_caps.max_total_ownership:
        known = [i for i in idx_range if players[i].ownership is not None]
        missing = [i for i in idx_range if players[i].ownership is None]
        model += pulp.lpSum(players[i].ownership * x[i] for i in known) <= (
            tag_caps.max_total_ownership + 900.0 * pulp.lpSum(x[i] for i in missing)
        )

    # Exposure caps
    if exposure_remaining:
        for i in idx_range:
            pid = players[i].player_id
            remaining = exposure_remaining.get(pid)
            if remaining is not None and remaining <= 0:
                model += x[i] == 0
    if required_player_ids:
        for player_id in sorted(required_player_ids):
            required_indexes = [
                i for i, player in enumerate(players) if player.player_id == player_id
            ]
            if required_indexes:
                model += pulp.lpSum(x[i] for i in required_indexes) == 1
    if minimum_player_groups:
        for player_ids, minimum_count in minimum_player_groups:
            model += pulp.lpSum(x[i] for i in idx_range
                                if players[i].player_id in player_ids) >= minimum_count
    if maximum_player_groups:
        for player_ids, maximum_count in maximum_player_groups:
            model += pulp.lpSum(x[i] for i in idx_range
                                if players[i].player_id in player_ids) <= maximum_count

    # Prevent the solver from selecting the same player multiple times when duplicate rows exist
    by_id: Dict[str, List[int]] = {}
    for i, p in enumerate(players):
        by_id.setdefault(p.player_id, []).append(i)
    for pid, idxs in by_id.items():
        if len(idxs) > 1:
            model += pulp.lpSum(x[i] for i in idxs) <= 1
    # Extra guard: collapse duplicate name+team combos that slipped through id mismatches
    by_name_team: Dict[tuple[str, str], List[int]] = {}
    for i, p in enumerate(players):
        key = (p.name.lower().strip(), p.team.upper().strip())
        by_name_team.setdefault(key, []).append(i)
    for key, idxs in by_name_team.items():
        if len(idxs) > 1:
            model += pulp.lpSum(x[i] for i in idxs) <= 1

    # Uniqueness
    for lineup in exclude_lineups:
        model += pulp.lpSum(x[i] for i in sorted(lineup)) <= config.uniqueness_overlap

    solver = make_cbc_solver(solver_backend)
    status = model.solve(solver)
    if status != pulp.LpStatusOptimal:
        return None

    selected = [i for i in idx_range if pulp.value(x[i]) >= 0.9]
    if control_comparisons is not None:
        replay = solve_control(model, control_objective)
        replay["variable_players"] = {
            variable.name: {"player_id": players[i].player_id, "roster_position": players[i].position}
            for i, variable in x.items()
        }
        control_indices = [i for i in idx_range if replay["values"].get(x[i].name, 0) >= 0.9]
        def records(indices):
            return [{**asdict(players[i]), "p90": players[i].ceiling} for i in indices]
        control_comparisons.append(build_comparison(
            records(selected), records(control_indices), replay, profile=correlation_profile,
            context_multiplier=context_multiplier,
            correlation_multiplier=weights.correlation * config.correlation_bonus,
        ))
    return selected


def _lineup_stats(players: List[Player], idxs: List[int]) -> Tuple[float | None, int, int, int]:
    total_ownership = (sum(players[i].ownership for i in idxs)
                       if all(players[i].ownership is not None for i in idxs) else None)
    chalk = sum(1 for i in idxs if "chalk" in players[i].tags)
    leverage = sum(1 for i in idxs if "leverage" in players[i].tags)
    punts = sum(1 for i in idxs if "punt" in players[i].tags)
    return total_ownership, chalk, leverage, punts


def _portfolio_stats(players: List[Player], lineups: List[List[int]]) -> PortfolioStats:
    exposure_counts: Dict[str, int] = {}
    tag_counts: Dict[str, int] = {"chalk": 0, "leverage": 0, "punt": 0}
    ownership_totals = []
    template_scores = []
    template_score_counts: Dict[str, int] = {"strong": 0, "neutral": 0, "weak": 0}
    stack_summary: Dict[str, int] = {}

    for idxs in lineups:
        lineup_players = [players[i] for i in idxs]
        for i in idxs:
            pid = players[i].player_id
            exposure_counts[pid] = exposure_counts.get(pid, 0) + 1
            for tag in players[i].tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        if all(players[i].ownership is not None for i in idxs):
            ownership_totals.append(sum(players[i].ownership for i in idxs))
        template_score = classic_template_score(lineup_players)
        if template_score is not None:
            template_scores.append(template_score)
            template_score_counts[template_score_bucket(template_score)] += 1
        # Stack type summary: count pass catchers/bring backs for QB
        qbs = [i for i in idxs if players[i].position == "QB"]
        if qbs:
            qb = players[qbs[0]]
            same_team = sum(1 for i in idxs if players[i].team == qb.team and players[i].position in ("WR", "TE", "RB") and i != qbs[0])
            bring_back = sum(1 for i in idxs if players[i].team == qb.opponent)
            key = f"{same_team}-with-qb_{bring_back}-bringback"
            stack_summary[key] = stack_summary.get(key, 0) + 1

    total_lineups = max(1, len(lineups))
    exposures = {pid: count / total_lineups for pid, count in exposure_counts.items()}
    avg_total_ownership = (sum(ownership_totals) / len(ownership_totals)
                           if ownership_totals and len(ownership_totals) == len(lineups) else None)
    avg_template_score = (sum(template_scores) / len(template_scores)
                          if template_scores and len(template_scores) == len(lineups) else None)
    return PortfolioStats(
        exposures=exposures,
        tag_counts=tag_counts,
        avg_total_ownership=avg_total_ownership,
        stack_summary=stack_summary,
        avg_template_score=avg_template_score,
        template_score_counts=template_score_counts,
    )


def _adjust_config_for_targets(config: SlateConfig, stats: PortfolioStats, targets: PortfolioTargets) -> SlateConfig:
    cfg = config
    # Adjust lineup ownership cap if average too high
    if (targets.max_avg_ownership and stats.avg_total_ownership is not None
            and stats.avg_total_ownership > targets.max_avg_ownership
            and cfg.tag_caps.max_total_ownership):
        cfg = SlateConfig(**{**cfg.__dict__})
        cfg.tag_caps = LineupTagCaps(**{**cfg.tag_caps.__dict__})
        cfg.tag_caps.max_total_ownership = max(100.0, cfg.tag_caps.max_total_ownership - 10.0)
    return cfg


def generate_portfolio(
    season: int,
    week: int,
    slate: str,
    num_lineups: int,
    engine: Engine | None = None,
    config_builder: Callable[[SlateAnalysis], SlateConfig] = build_slate_config,
    players: List[Player] | None = None,
    ownership_available: bool | None = None,
    max_exposure: float = 0.5,
    enforce_single_te: bool = False,
    avoid_dst_opponents: bool = False,
    minimum_uniqueness: int | None = None,
    max_from_team: int | None = None,
    max_from_game: int | None = None,
    stack_templates: Sequence[Tuple[int, int]] | None = None,
    maximum_exposure_by_player: Dict[str, float] | None = None,
    minimum_exposure_by_player: Dict[str, float] | None = None,
    include_control_comparisons: bool = True,
    long_shot_mode: bool = False,
    candidate_aware_ownership: bool = False,
    solver_backend: str = "bundled",
    precompute_correlation_terms: bool = False,
    maximum_player_groups: Sequence[tuple[set[str], int]] | None = None,
) -> GPPOptimizerResult:
    engine = engine or create_engine(get_connection_string())
    if players is None:
        players, counts = load_player_pool(engine, season, week, slate)
    else:
        players = list(players)
        counts = {
            "salaries": len(players),
            "projections": len(players),
            "ownership": int(
                ownership_available
                if ownership_available is not None
                else any(player.ownership is not None for player in players)
            ),
            "kept": len(players),
        }
    if not players:
        raise RuntimeError(
            "No player pool found for slate "
            f"(salaries={counts.get('salaries', 0)}, projections={counts.get('projections', 0)}, "
            f"ownership={counts.get('ownership', 0)}, kept={counts.get('kept', 0)}, "
            f"dropped_salary={counts.get('dropped_salary', 0)}, "
            f"dropped_pos={counts.get('dropped_pos', 0)}, dropped_proj={counts.get('dropped_proj', 0)})."
        )

    # Tag + analysis + config
    analysis = analyze_slate(players)
    if config_builder is build_large_gpp_config:
        def resolved_builder(current_analysis: SlateAnalysis) -> SlateConfig:
            return build_large_gpp_config(
                current_analysis,
                ownership_available=bool(ownership_available),
                minimum_uniqueness=minimum_uniqueness or 2,
                max_from_team=max_from_team,
                max_from_game=max_from_game,
                stack_templates=stack_templates,
                maximum_exposure_by_player=maximum_exposure_by_player,
                minimum_exposure_by_player=minimum_exposure_by_player,
                candidate_aware_ownership=candidate_aware_ownership,
            )
    else:
        resolved_builder = config_builder
    base_config = resolved_builder(analysis)
    tag_players(players, base_config.tag_thresholds)
    config = resolved_builder(analysis)
    if long_shot_mode:
        if num_lineups != 1:
            raise ValueError("Long-shot mode requires exactly one lineup")
        if bool(ownership_available) and all(player.ownership is not None for player in players):
            # Directly optimize low ownership.  This deliberately does not
            # modify mean, ceiling, role, or any other football input.
            for player in players:
                player.leverage = -float(player.ownership)
        config = build_long_shot_config(
            config,
            ownership_available=bool(ownership_available),
        )
    leverage_available = any(
        player.optimal_lineup_probability is not None for player in players
    )
    if not leverage_available and config.tag_caps.min_leverage:
        config = SlateConfig(**{**config.__dict__})
        config.tag_caps = LineupTagCaps(**{**config.tag_caps.__dict__})
        config.tag_caps.min_leverage = 0
        config.portfolio_targets = PortfolioTargets(
            **{**config.portfolio_targets.__dict__, "min_leverage_count": 0}
        )
    # If no ownership data, relax tag constraints so the solver can build lineups
    if counts.get("ownership", 0) == 0:
        config = SlateConfig(
            stack_rules=config.stack_rules,
            tag_thresholds=config.tag_thresholds,
            objective_weights=config.objective_weights,
            tag_caps=LineupTagCaps(
                max_chalk=len(players),
                min_leverage=0,
                max_punts=(config.tag_caps.max_punts if config.normalize_objective else len(players)),
                max_total_ownership=None,
            ),
            salary_cap=config.salary_cap,
            roster_size=config.roster_size,
            portfolio_targets=config.portfolio_targets,
            correlation_bonus=config.correlation_bonus,
            uniqueness_overlap=config.uniqueness_overlap,
            normalize_objective=config.normalize_objective,
            stack_templates=config.stack_templates,
        )
    correlation_terms = None
    format_terms = None
    if precompute_correlation_terms:
        correlation_profile = resolve_strategy_profile(
            contest_format="classic", objective="gpp"
        )
        correlation_terms = build_lineup_correlation_terms(
            players, profile=correlation_profile
        )
        format_terms = build_format_specific_terms(
            players, profile=correlation_profile
        )
    # Small slates (few teams) need a higher per-team cap to satisfy a 9-man roster
    unique_teams = {p.team for p in players if p.team}
    min_team_cap = math.ceil(config.roster_size / max(1, len(unique_teams) or 1))
    if config.stack_rules.max_from_team < min_team_cap:
        config = SlateConfig(**{**config.__dict__})
        config.stack_rules = StackRules(**{**config.stack_rules.__dict__})
        config.stack_rules.max_from_team = min(4, min_team_cap)

    exclude_lineups: List[set] = []
    used_counts: Dict[str, int] = {}
    lineups: List[List[int]] = []
    control_comparisons: List[dict] = []
    solved_count = 0
    infeasible_count = 0

    iterations = 0
    max_iterations = 3
    max_exposure = max(0.01, min(1.0, float(max_exposure)))
    requested_minimums = {
        str(player_id): max(0.0, min(1.0, float(exposure)))
        for player_id, exposure in config.portfolio_targets.player_exposure_mins.items()
    }
    requested_maximums = {
        str(player_id): max(0.0, min(1.0, float(exposure)))
        for player_id, exposure in config.portfolio_targets.player_exposure_caps.items()
    }
    known_player_ids = {player.player_id for player in players}
    unknown_exposure_ids = (
        set(requested_minimums) | set(requested_maximums)
    ) - known_player_ids
    if unknown_exposure_ids:
        raise ValueError(
            "Exposure controls reference players outside the candidate pool: "
            + ", ".join(sorted(unknown_exposure_ids))
        )
    conflicting_exposure_ids = {
        player_id
        for player_id, minimum in requested_minimums.items()
        if player_id in requested_maximums
        and math.ceil(num_lineups * minimum)
        > math.floor(num_lineups * requested_maximums[player_id])
    }
    if conflicting_exposure_ids:
        raise ValueError(
            "Minimum exposure exceeds maximum exposure for: "
            + ", ".join(sorted(conflicting_exposure_ids))
        )

    def exposure_limit_for(player_id: str, default_limit: int) -> int:
        required_limit = math.ceil(
            num_lineups * requested_minimums.get(player_id, 0.0)
        )
        requested_limit = (
            math.floor(num_lineups * requested_maximums[player_id])
            if player_id in requested_maximums
            else num_lineups
        )
        return min(requested_limit, max(default_limit, required_limit))

    while iterations < max_iterations and len(lineups) < num_lineups:
        iterations += 1
        exposure_limit = max(1, math.ceil(num_lineups * max_exposure))
        remaining = {
            p.player_id: exposure_limit_for(p.player_id, exposure_limit)
            - used_counts.get(p.player_id, 0)
            for p in players
        }

        new_lineups: List[List[int]] = []
        for lineup_offset in range(num_lineups - len(lineups)):
            lineups_remaining = num_lineups - len(lineups) - len(new_lineups)
            required_now = {
                player_id
                for player_id, exposure in requested_minimums.items()
                if math.ceil(num_lineups * exposure)
                - used_counts.get(player_id, 0)
                >= lineups_remaining
            }
            template = (
                config.stack_templates[
                    (len(lineups) + len(new_lineups)) % len(config.stack_templates)
                ]
                if config.stack_templates
                else (
                    config.stack_rules.min_pass_catchers,
                    config.stack_rules.min_bring_backs,
                )
            )
            lineup_stack_rules = StackRules(
                **{
                    **config.stack_rules.__dict__,
                    "min_pass_catchers": int(template[0]),
                    "min_bring_backs": int(template[1]),
                }
            )
            lineup_idxs = _build_lineup(
                players,
                config,
                remaining,
                exclude_lineups,
                enforce_single_te=enforce_single_te,
                avoid_dst_opponents=avoid_dst_opponents,
                stack_rules=lineup_stack_rules,
                required_player_ids=required_now,
                control_comparisons=control_comparisons if include_control_comparisons else None,
                solver_backend=solver_backend,
                precomputed_correlation_terms=correlation_terms,
                precomputed_format_terms=format_terms,
                maximum_player_groups=maximum_player_groups,
            )
            if not lineup_idxs:
                infeasible_count += 1
                break
            solved_count += 1
            new_lineups.append(lineup_idxs)
            for idx in lineup_idxs:
                pid = players[idx].player_id
                used_counts[pid] = used_counts.get(pid, 0) + 1
            exclude_lineups.append(set(lineup_idxs))
            remaining = {
                p.player_id: exposure_limit_for(p.player_id, exposure_limit)
                - used_counts.get(p.player_id, 0)
                for p in players
            }

        lineups.extend(new_lineups)
        stats = _portfolio_stats(players, lineups)
        config = _adjust_config_for_targets(config, stats, config.portfolio_targets)

    unmet_minimums = {
        player_id: {
            "required": math.ceil(num_lineups * exposure),
            "generated": used_counts.get(player_id, 0),
        }
        for player_id, exposure in requested_minimums.items()
        if used_counts.get(player_id, 0) < math.ceil(num_lineups * exposure)
    }
    incomplete_portfolio = config.normalize_objective and len(lineups) != num_lineups
    status = (
        "completed"
        if lineups and not unmet_minimums and not incomplete_portfolio
        else "failed"
    )
    message = f"Generated {len(lineups)} lineup(s) after {iterations} iteration(s)"
    if incomplete_portfolio:
        message += f"; requested {num_lineups}"
    if unmet_minimums:
        message += "; unsatisfied minimum exposures: " + ", ".join(
            f"{player_id} {counts['generated']}/{counts['required']}"
            for player_id, counts in sorted(unmet_minimums.items())
        )
    for comparison in control_comparisons:
        for metric, available in (("ownership_sum", bool(counts.get("ownership", 0))),
                                  ("leverage_sum", leverage_available)):
            if not available:
                comparison["scored_metrics"][metric] = None
                comparison["control_metrics"][metric] = None
                comparison["deltas_scored_minus_control"][metric] = None
    result = GPPOptimizerResult(
        job_id=str(uuid.uuid4()),
        status=status,
        message=message,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
        lineups=[[players[i] for i in idxs] for idxs in lineups],
        config=config,
        analysis=analysis,
        portfolio=_portfolio_stats(players, lineups),
        iterations=iterations,
        control_comparisons=control_comparisons,
        generation_funnel={
            "requested": num_lineups, "solved": solved_count,
            "legal": solved_count, "duplicate": 0,
            "rejected_by_quality": 0, "rejected_by_player_cap": None,
            "rejected_by_injury_cap": None, "rejected_by_family_constraint": None,
            "accepted": len(lineups), "remaining_deficit": num_lineups - len(lineups),
            "infeasible_solver_attempts": infeasible_count,
            "status": "CANDIDATE_POOL_UNDERFILLED" if len(lineups) < num_lineups else "complete",
        },
    )
    return result


def export_lineups_to_csv(result: GPPOptimizerResult, path: str) -> None:
    rows = []
    for i, lineup in enumerate(result.lineups, start=1):
        for p in lineup:
            rows.append(
                {
                    "lineup": i,
                    "player_id": p.player_id,
                    "name": p.name,
                    "position": p.position,
                    "team": p.team,
                    "opponent": p.opponent,
                    "salary": p.salary,
                    "projection": p.projection,
                    "ownership": p.ownership,
                    "ownership_bucket": ownership_bucket(p.ownership),
                }
            )
    pd.DataFrame(rows).to_csv(path, index=False)


def export_summary_to_md(result: GPPOptimizerResult, path: str) -> None:
    lines = [
        "# Portfolio Summary",
        f"- Status: {result.status}",
        f"- Message: {result.message}",
        f"- Lineups: {len(result.lineups)}",
        f"- Avg total ownership: {result.portfolio.avg_total_ownership:.2f}"
        if result.portfolio.avg_total_ownership is not None else "- Avg total ownership: unavailable",
        f"- Avg ownership-template score: {result.portfolio.avg_template_score:.2f}"
        if result.portfolio.avg_template_score is not None else "- Avg ownership-template score: unavailable",
        "",
        "## Stack Types",
    ]
    for key, count in sorted(result.portfolio.stack_summary.items(), key=lambda kv: kv[0]):
        lines.append(f"- {key}: {count}")
    lines.append("")
    lines.append("## Tag Counts")
    for tag, count in result.portfolio.tag_counts.items():
        lines.append(f"- {tag}: {count}")
    lines.append("")
    lines.append("## Ownership Template Fit")
    for bucket, count in result.portfolio.template_score_counts.items():
        lines.append(f"- {bucket}: {count}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def summarize_slate(players: List[Player], analysis: SlateAnalysis) -> dict:
    return {
        "game_count": analysis.game_count,
        "chalk_concentration": analysis.chalk_concentration,
        "feature_games": analysis.feature_games,
        "player_count": len(players),
    }


def summarize_portfolio(result: GPPOptimizerResult) -> dict:
    return {
        "status": result.status,
        "lineups": len(result.lineups),
        "avg_total_ownership": result.portfolio.avg_total_ownership,
        "avg_template_score": result.portfolio.avg_template_score,
        "template_score_counts": result.portfolio.template_score_counts,
        "stack_summary": result.portfolio.stack_summary,
        "tag_counts": result.portfolio.tag_counts,
        "config": result.config,
    }


def run_gpp_pipeline(
    season: int,
    week: int,
    slate: str,
    num_lineups: int = 20,
    export_dir: str | None = None,
    engine: Engine | None = None,
    players: List[Player] | None = None,
    ownership_available: bool | None = None,
    max_exposure: float = 0.5,
    enforce_single_te: bool = False,
    avoid_dst_opponents: bool = False,
    large_gpp: bool = False,
    minimum_uniqueness: int | None = None,
    max_from_team: int | None = None,
    max_from_game: int | None = None,
    stack_templates: Sequence[Tuple[int, int]] | None = None,
    maximum_exposure_by_player: Dict[str, float] | None = None,
    minimum_exposure_by_player: Dict[str, float] | None = None,
    include_control_comparisons: bool = True,
    long_shot_mode: bool = False,
    candidate_aware_ownership: bool = False,
    solver_backend: str = "bundled",
    precompute_correlation_terms: bool = False,
    maximum_player_groups: Sequence[tuple[set[str], int]] | None = None,
) -> GPPOptimizerResult:
    """End-to-end entry point: load slate, build config, generate portfolio, export results."""
    result = generate_portfolio(
        season,
        week,
        slate,
        num_lineups,
        engine=engine,
        config_builder=build_large_gpp_config if large_gpp else build_slate_config,
        players=players,
        ownership_available=ownership_available,
        max_exposure=max_exposure,
        enforce_single_te=enforce_single_te,
        avoid_dst_opponents=avoid_dst_opponents,
        minimum_uniqueness=minimum_uniqueness,
        max_from_team=max_from_team,
        max_from_game=max_from_game,
        stack_templates=stack_templates,
        maximum_exposure_by_player=maximum_exposure_by_player,
        minimum_exposure_by_player=minimum_exposure_by_player,
        include_control_comparisons=include_control_comparisons,
        long_shot_mode=long_shot_mode,
        candidate_aware_ownership=candidate_aware_ownership,
        solver_backend=solver_backend,
        precompute_correlation_terms=precompute_correlation_terms,
        maximum_player_groups=maximum_player_groups,
    )
    if export_dir:
        csv_path = f"{export_dir}/lineups_{slate}_{season}w{week}.csv"
        md_path = f"{export_dir}/summary_{slate}_{season}w{week}.md"
        export_lineups_to_csv(result, csv_path)
        export_summary_to_md(result, md_path)
    return result
